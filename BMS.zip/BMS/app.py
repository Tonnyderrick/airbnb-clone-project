from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# File upload settings
UPLOAD_FOLDER = 'uploads/'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Helper function to check allowed file types
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Initialize the SQLite database
def init_db():
    with sqlite3.connect("users.db") as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS users (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            email TEXT UNIQUE NOT NULL,
                            password TEXT NOT NULL,
                            name TEXT
                        )''')
        conn.execute('''CREATE TABLE IF NOT EXISTS bursaries (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            user_id INTEGER,
                            full_name TEXT,
                            institution TEXT,
                            county TEXT,
                            document_path TEXT,
                            reason TEXT,
                            status TEXT,
                            FOREIGN KEY(user_id) REFERENCES users(id)
                        )''')

init_db()

# 🔥 Home route
@app.route('/')
def home():
    return redirect(url_for('apply_bursary'))

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Check if the email exists in the database
        conn = sqlite3.connect("users.db")
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email = ?", (email,))
        user = cur.fetchone()
        conn.close()

        if user and check_password_hash(user[2], password):  # Check password hash
            session['user_id'] = user[0]  # Store user ID in the session
            flash("Login successful!", 'success')
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid email or password", 'danger')

    return render_template('login.html')

# Sign up route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        fullname = request.form['fullname']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # Ensure passwords match
        if password != confirm_password:
            flash("Passwords don't match", 'danger')
            return redirect(url_for('signup'))

        # Check if the email already exists
        conn = sqlite3.connect("users.db")
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email = ?", (email,))
        existing_user = cur.fetchone()

        if existing_user:
            flash("Email already registered", 'danger')
            return redirect(url_for('signup'))

        # Hash the password before saving it
        hashed_password = generate_password_hash(password)

        # Insert new user into the database
        cur.execute("INSERT INTO users (email, password, name) VALUES (?, ?, ?)", 
                    (email, hashed_password, fullname))
        conn.commit()
        conn.close()

        flash("Account created successfully! Please log in.", 'success')
        return redirect(url_for('login'))

    return render_template('signup.html')

# Apply for a new bursary
@app.route('/apply_bursary', methods=['GET', 'POST'])
def apply_bursary():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        # Collect form data
        full_name = request.form['full_name']
        institution = request.form['institution']
        county = request.form['county']
        reason = request.form['reason']

        # Handle file upload
        if 'document' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)

        file = request.files['document']
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            # Store bursary application in the database
            user_id = session.get('user_id')
            conn = sqlite3.connect("users.db")
            cur = conn.cursor()
            cur.execute('''INSERT INTO bursaries (user_id, full_name, institution, county, document_path, reason, status)
                           VALUES (?, ?, ?, ?, ?, ?, ?)''', 
                           (user_id, full_name, institution, county, file_path, reason, 'Pending'))
            conn.commit()
            conn.close()

            flash('Bursary application submitted successfully!', 'success')
            return redirect(url_for('dashboard'))  # Redirect to the dashboard after submission

    return render_template('apply_bursary.html')

# Dashboard route
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    # Fetch user's bursary applications or other info
    user_id = session['user_id']
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM bursaries WHERE user_id = ?", (user_id,))
    applications = cur.fetchall()
    conn.close()

    return render_template('dashboard.html', applications=applications)

if __name__ == '__main__':
    print("🚀 Starting Flask app on http://127.0.0.1:5000")
    app.run(debug=True)
